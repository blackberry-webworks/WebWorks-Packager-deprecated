/*
 * Copyright 2010-2011 Research In Motion Limited.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * Creates a new BBMChat. This manages the HTML elements of the chat, and provides toggle()
 * and extractReplyText() functionality.
 * 
 * <p>The controller requires that the chat is laid out with a message list and a footer, as follows:
 * 
 * <code>
 * <div name="frame">
 *     <div name="message-list" class="bbm-chat-message-list">
 *     </div>
 *     <div name="filler">
 *     </div>
 *     <div name="footer" class="bbm-chat-footer">
 *         <div name="controls" class="bbm-chat-controls">
 *             <div class="bbm-chat-reply-frame">
 *             <input name="reply" class="bbm-chat-reply" type="text"/>
 *             </div>
 *             <div class="bbm-chat-reply-separator">
 *             </div>
 *         </div>
 *         <div name="toggle" class="bbm-chat-toggle">
 *             <img />
 *         </div>
 *     </div>
 * </div>
 * </code>
 * 
 * <p>Styling can be customized to an extent. Look for examples in bbmChat.css.
 * 
 * <p>The following files should be included in the project:
 * <ul>
 * <li>images/bbmChat/arrow_up_large.png
 * <li>images/bbmChat/arrow_down_large.png
 * </ul>
 * 
 * 
 */
var BBMChat = function (frameDiv, messageListDiv, fillerDiv, footerDiv, replyInput, chatControlsDiv, chatToggleDiv) {
    this.frame = frameDiv;
    this.messageList = new BBMMessageList(messageListDiv);
    this.fillerDiv = fillerDiv;
    this.footerDiv = footerDiv;
    this.replyInput = replyInput;
    this.chatControlsDiv = chatControlsDiv;
    this.chatToggleDiv = chatToggleDiv;
    this.showing = false;
    
    // Invoke a toggle to hide the chat controls. This will perform the initial layout
    this.toggle(false);
    
    // Set solid background in BB5 browser, since it does not support gradient backgrounds
    if (this.isBB5()) {
        this.chatToggleDiv.style.backgroundColor = "#303943";
    }
};

/**
 * Toggles the BBM chat controls
 * @param [show] {Boolean} Forces the toggle state if provided. If not provided, the toggle state is flipped. 
 */
BBMChat.prototype.toggle = function (show) {
    // Force toggle state if provided
    if (show !== undefined) {
        this.showing = show;
    // Otherwise toggle it
    } else {
        this.showing = !this.showing;
    }

    var chatToggleImgSrc, chatControlsDisplay, chatToggleImg;

    // Show the chat message list and controls
    if (this.showing) {
        chatControlsDisplay = "block";
        chatToggleImgSrc = "images/bbmChat/arrow_down_large.png";
    // Hide the chat message list and controls
    } else {
        chatControlsDisplay = "none";
        chatToggleImgSrc = "images/bbmChat/arrow_up_large.png";
    }

    chatToggleImg = this.getToggleImg();
    if (chatToggleImg) {
        chatToggleImg.src = chatToggleImgSrc;
    }
    this.chatControlsDiv.style.display = chatControlsDisplay;

    // Resize the content filler div so that we can scroll to the bottom of the content.
    this.fillerDiv.style.height = this.chatControlsDiv.offsetHeight + this.chatToggleDiv.offsetHeight + "px";
    
    // Relayout the footer in BB5
    this.layoutFooter();
};

/**
 * Gets the reply text, clears the reply field, and places focus back on the reply field.
 * <p>This method should be called as part of the reply mechanism. For example, the replyInput's
 * onkeypress event should capture the enter key, call this method, and send the reply.
 * @returns the reply text.
 */
BBMChat.prototype.extractReplyText = function () {
    var replyText = this.replyInput.value;
    this.replyInput.value = "";
    this.replyInput.focus();
    return replyText;
};

/**
 * Aligns the BBM chat footer for BB5 browser. In BB5, fixed positioning via bottom=0px is not
 * supported. Therefore the footer is aligned via the top. This must be re-calculated when the chat
 * controls are toggled.
 */
BBMChat.prototype.layoutFooter = function () {
    // Align footer via top in BB5
    if (this.isBB5()) {
        var chatControlsHeight = 50;
        var chatToggleHeight = 25;
        if (this.showing) {
            this.footerDiv.style.top = screen.height - chatToggleHeight - chatControlsHeight + 'px';
        } else {
            this.footerDiv.style.top = screen.height - chatToggleHeight + 'px';
        }
    }
};


/**
 * Returns <code>true</code> if the device is BB5, <code>false</code> otherwise.
 * @returns <code>true</code> if the device is BB5, <code>false</code> otherwise.
 */
BBMChat.prototype.isBB5 = function () {
    return navigator.appVersion.indexOf('5.0.0') >= 0;
};

// PRIVATE
BBMChat.prototype.getToggleImg = function () {
    var imgs = this.chatToggleDiv.getElementsByTagName("img");
    if (imgs.length > 0) {
        return imgs[0];
    } else {
        return undefined;
    }
};