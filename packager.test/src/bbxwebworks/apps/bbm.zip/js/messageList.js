/**
 * Creates a new message list.
 * @param messageListDiv The message list div.
 */
var BBMMessageList = function (messageListDiv) {
    this.msgListDiv = messageListDiv;
    this.empty = true;
    this.clear();
};

BBMMessageList.prototype.appendChild = function (div) {
    if (this.empty) {
        this.empty = false;
        this.msgListDiv.innerHTML = "";
    }
    this.msgListDiv.appendChild(div);
};
/*
 * Copyright 2010-2011 Research In Motion Limited.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

BBMMessageList.prototype.appendTextDiv = function (message, className) {
    var messageDiv = document.createElement("div");
    messageDiv.appendChild(document.createTextNode(message));
    messageDiv.className = className;
    this.appendChild(messageDiv);
};

BBMMessageList.prototype.appendInMessage = function (userName, message) {
    var elem = document.createElement("div");
    elem.innerHTML = '<div class="right-panel"><div class="right-top-left"></div><div class="right-top-right"></div><div class="right-inside"><div class="right-nogap"><div class="details">' + this.createBubbleDetails(userName, message) + '</div></div></div><div class="right-bottom-left"></div><div class="right-bottom-right"></div></div>';
    this.appendChild(elem);
};

BBMMessageList.prototype.appendOutMessage = function (userName, message) {
    var elem = document.createElement("div");
    elem.innerHTML = '<div class="left-panel"><div class="left-top-left"></div><div class="left-top-right"></div><div class="left-inside"><div class="left-nogap"><div class="details">' + this.createBubbleDetails(userName, message) + '</div></div></div><div class="left-bottom-left"></div><div class="left-bottom-right"></div></div>';
    this.appendChild(elem);
};

//TODO PRIVATE
BBMMessageList.prototype.createBubbleDetails = function (userName, message) {
    return '<span class="bubble-user-name">' + userName + '</span><div class="separator"></div><span class="bubble-message">' + message + '</span>';
};

BBMMessageList.prototype.appendSystemMessage = function (message) {
    this.appendTextDiv(message, "message-system");
};

BBMMessageList.prototype.appendDebugMessage = function (message) {
    this.appendTextDiv(message, "message-debug");
};

BBMMessageList.prototype.clear = function () {
    this.msgListDiv.innerHTML = "";
    this.empty = true;
};